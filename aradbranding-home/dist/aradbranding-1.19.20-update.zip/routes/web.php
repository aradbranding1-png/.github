<?php

declare(strict_types=1);

use App\Core\Http\Router;
use App\Install\InstallerController;
use App\Modules\Dashboard\DashboardController;
use App\Modules\Ops\OpsController;
use App\Modules\Pages\PageController;
use App\Modules\Pages\PublicPageController;
use App\Modules\System\HealthController;
use App\Modules\System\HomeController;
use App\Modules\Users\AccountController;
use App\Modules\Users\AuthController;
use App\Modules\Payments\PaymentController;
use App\Modules\Wallet\WalletController;
use App\Modules\Proposals\ProposalController;
use App\Modules\Admin\SettingsController;
use App\Modules\Letters\ConnectionController;
use App\Modules\Letters\LetterController;
use App\Modules\Notifications\NotificationController;

return static function (Router $r): void {
    $r->get('/', [HomeController::class, 'index'], ['session:optional']);
    $r->get('/lang/{code:[a-z]{2}}', [\App\Modules\System\LocaleController::class, 'switch'], ['session:optional']);

    // Guests
    $r->group('', ['session', 'guest'], static function (Router $r): void {
        $r->get('/login', [AuthController::class, 'showLogin']);
        $r->post('/login', [AuthController::class, 'login'], ['csrf', 'throttle:login']);
        $r->get('/register', [AuthController::class, 'showRegister']);
        $r->post('/register', [AuthController::class, 'register'], ['csrf', 'throttle:register']);
        // Sign-up with Google: the account details Google does not give (mobile, country, language) in one short step.
        $r->get('/register/google', [AuthController::class, 'showGoogleRegister']);
        $r->post('/register/google', [AuthController::class, 'googleRegister'], ['csrf', 'throttle:register']);
    });

    // Google sign-in (guests) and "connect Google" (signed-in members) share one start and one callback.
    $r->group('', ['session'], static function (Router $r): void {
        $r->get('/auth/google', [\App\Modules\Users\GoogleController::class, 'start']);
        $r->get('/auth/google/callback', [\App\Modules\Users\GoogleController::class, 'callback'], ['throttle:login']);
    });

    // Signed-in users
    $r->group('', ['session', 'auth', 'csrf'], static function (Router $r): void {
        $r->post('/logout', [AuthController::class, 'logout']);
        $r->get('/dashboard', [DashboardController::class, 'index']);
        $r->get('/reports', [\App\Modules\Dashboard\ReportsController::class, 'index']);

        $r->get('/account', [AccountController::class, 'show']);
        $r->post('/account', [AccountController::class, 'updateProfile']);
        $r->post('/account/password', [AccountController::class, 'updatePassword'], ['throttle:login']);
        $r->post('/account/google', [AccountController::class, 'updateGoogle']);
        $r->post('/account/google/unlink', [AccountController::class, 'unlinkGoogle']);

        $r->get('/pages', [PageController::class, 'index']);
        $r->get('/pages/new', [PageController::class, 'create']);
        $r->post('/pages', [PageController::class, 'store']);
        $r->post('/pages/routes', [PageController::class, 'addRule']);
        $r->post('/pages/routes/{rule:\d+}/delete', [PageController::class, 'deleteRule']);
        $r->get('/pages/{uid:[0-9a-z]{26}}/edit', [PageController::class, 'edit']);
        $r->post('/pages/{uid:[0-9a-z]{26}}', [PageController::class, 'update']);
        $r->post('/pages/{uid:[0-9a-z]{26}}/toggle', [PageController::class, 'toggle']);
        $r->post('/pages/{uid:[0-9a-z]{26}}/default', [PageController::class, 'makeDefault']);

        $r->get('/wallet', [WalletController::class, 'index']);
        $r->post('/wallet/buy', [WalletController::class, 'buy'], ['throttle:payment']);
        $r->get('/payments/test', [PaymentController::class, 'testGateway']);
        $r->get('/payments/{uid:[0-9a-z]{26}}', [PaymentController::class, 'show']);
        $r->post('/p/{handle:[a-z0-9-]{3,32}}/{lang:[a-z]{2,3}}/unlock', [PublicPageController::class, 'unlock']);
        $r->post('/account/interests', [AccountController::class, 'updateInterests']);

        // Trust & Safety (member side) and personal API keys
        $r->get('/account/safety', [\App\Modules\Trust\SafetyController::class, 'index']);
        $r->post('/reports', [\App\Modules\Trust\SafetyController::class, 'report'], ['throttle:letter']);
        $r->post('/blocks/{id:\d+}', [\App\Modules\Trust\SafetyController::class, 'block']);
        $r->post('/blocks/{id:\d+}/delete', [\App\Modules\Trust\SafetyController::class, 'unblock']);
        $r->get('/account/api', [\App\Modules\Integrations\ApiKeyController::class, 'index']);
        $r->post('/account/api', [\App\Modules\Integrations\ApiKeyController::class, 'create'], ['throttle:login']);
        $r->post('/account/api/{id:\d+}/revoke', [\App\Modules\Integrations\ApiKeyController::class, 'revoke']);

        $r->get('/proposals', [ProposalController::class, 'feed']);
        $r->get('/proposals/more', [ProposalController::class, 'feedMore']);
        $r->get('/proposals/mine', [ProposalController::class, 'mine']);
        $r->get('/proposals/received', [ProposalController::class, 'received']);
        $r->get('/proposals/new', [ProposalController::class, 'create']);
        $r->post('/proposals', [ProposalController::class, 'store'], ['throttle:proposal']);
        $r->get('/proposals/send', [ProposalController::class, 'sendForm']);
        $r->post('/proposals/send', [ProposalController::class, 'send'], ['throttle:proposal']);
        $r->get('/proposals/{uid:[0-9a-z]{26}}', [ProposalController::class, 'show']);
        $r->get('/proposals/{uid:[0-9a-z]{26}}/edit', [ProposalController::class, 'edit']);
        $r->post('/proposals/{uid:[0-9a-z]{26}}', [ProposalController::class, 'update']);
        $r->post('/proposals/{uid:[0-9a-z]{26}}/publish', [ProposalController::class, 'publish']);
        $r->post('/proposals/{uid:[0-9a-z]{26}}/unpublish', [ProposalController::class, 'unpublish']);
        $r->post('/proposals/{uid:[0-9a-z]{26}}/delete', [ProposalController::class, 'destroy']);

        $r->get('/discover', [\App\Modules\Discover\DiscoverController::class, 'index']);
        $r->get('/discover/country/{id:\d+}', [\App\Modules\Discover\DiscoverController::class, 'country']);
        $r->get('/search', [\App\Modules\Discover\DiscoverController::class, 'search'], ['throttle:search']);

        $r->get('/letters', [LetterController::class, 'index']);
        $r->get('/letters/new', [LetterController::class, 'compose']);
        $r->post('/letters/new', [LetterController::class, 'sendPrivate'], ['throttle:letter']);
        $r->get('/letters/send', [LetterController::class, 'sendNew']);
        $r->post('/letters/send', [LetterController::class, 'sendQuote'], ['throttle:letter']);
        $r->get('/letters/public/new', static fn () => \App\Core\Http\Response::redirect('/letters/send', 301));
        $r->get('/letters/official/{uid:[0-9a-z]{26}}', [LetterController::class, 'official']);
        $r->get('/letters/public/{uid:[0-9a-z]{26}}', [LetterController::class, 'campaign']);
        $r->post('/letters/public/{uid:[0-9a-z]{26}}/send', [LetterController::class, 'publicConfirm'], ['throttle:letter']);
        $r->get('/letters/{uid:[0-9a-z]{26}}', [LetterController::class, 'show']);
        $r->post('/letters/{uid:[0-9a-z]{26}}/reply', [LetterController::class, 'reply'], ['throttle:letter']);
        $r->post('/letters/{uid:[0-9a-z]{26}}/archive', [LetterController::class, 'archive']);
        $r->get('/notifications', [NotificationController::class, 'index']);
        $r->get('/notifications/peek', [NotificationController::class, 'peek']);
        $r->post('/notifications/read', [NotificationController::class, 'readAll']);
        $r->get('/connections', [ConnectionController::class, 'index']);

        // ---- Admin (each route checks its own permission; data scope is applied inside) ----
        $r->get('/admin', [\App\Modules\Admin\DashboardAdminController::class, 'dashboard']);
        $r->get('/admin/reports', [\App\Modules\Admin\DashboardAdminController::class, 'reports'], ['can:reports.view']);
        $r->get('/admin/finance', [\App\Modules\Admin\DashboardAdminController::class, 'finance'], ['can:payments.view']);
        $r->post('/admin/finance/payments/{id:\d+}/delete', [\App\Modules\Admin\DashboardAdminController::class, 'deletePayment'], ['can:payments.delete']);
        $r->get('/admin/api', [\App\Modules\Admin\ApiAdminController::class, 'index'], ['can:settings.manage']);
        $r->post('/admin/api', [\App\Modules\Admin\ApiAdminController::class, 'create'], ['can:settings.manage']);
        $r->post('/admin/api/{id:\d+}/revoke', [\App\Modules\Admin\ApiAdminController::class, 'revoke'], ['can:settings.manage']);
        $r->get('/admin/trust', [\App\Modules\Admin\TrustAdminController::class, 'index']);
        $r->post('/admin/trust/{id:\d+}', [\App\Modules\Admin\TrustAdminController::class, 'resolve']);
        $r->post('/admin/wallet/{id:\d+}/refund/{tx:\d+}', [\App\Modules\Admin\WalletAdminController::class, 'refund'], ['can:payments.refund']);
        $r->post('/admin/api/settings', [\App\Modules\Admin\ApiAdminController::class, 'settings'], ['can:settings.manage']);
        $r->post('/admin/api/keys/{id:\d+}/revoke', [\App\Modules\Admin\ApiAdminController::class, 'revokeKey'], ['can:settings.manage']);
        $r->get('/admin/wallet', [\App\Modules\Admin\WalletAdminController::class, 'index'], ['can:wallet.view']);
        $r->post('/admin/wallet/{id:\d+}', [\App\Modules\Admin\WalletAdminController::class, 'adjust'], ['can:wallet.view']);
        $r->get('/admin/users', [\App\Modules\Admin\UserAdminController::class, 'index'], ['can:users.view']);
        $r->get('/admin/users/{id:\d+}', [\App\Modules\Admin\UserAdminController::class, 'show'], ['can:users.view']);
        $r->post('/admin/users/{id:\d+}/status', [\App\Modules\Admin\UserAdminController::class, 'setStatus'], ['can:users.edit']);
        $r->post('/admin/users/{id:\d+}/verify', [\App\Modules\Admin\UserAdminController::class, 'verify'], ['can:users.edit']);
        $r->post('/admin/users/{id:\d+}/wallet', [\App\Modules\Admin\UserAdminController::class, 'wallet'], ['can:wallet.view']);
        $r->post('/admin/users/{id:\d+}/roles', [\App\Modules\Admin\UserAdminController::class, 'roles'], ['can:roles.manage']);
        $r->post('/admin/users/{id:\d+}/impersonate', [\App\Modules\Admin\UserAdminController::class, 'impersonate'], ['can:users.impersonate']);
        $r->post('/admin/impersonate/stop', [\App\Modules\Admin\UserAdminController::class, 'stopImpersonating']);
        $r->get('/admin/content', [\App\Modules\Admin\ContentAdminController::class, 'index']);
        $r->post('/admin/content/pages/{id:\d+}', [\App\Modules\Admin\ContentAdminController::class, 'page'], ['can:pages.approve']);
        $r->post('/admin/content/proposals/{id:\d+}', [\App\Modules\Admin\ContentAdminController::class, 'proposal'], ['can:proposals.moderate']);
        $r->get('/admin/roles', [\App\Modules\Admin\RolesController::class, 'index'], ['can:roles.manage']);
        $r->post('/admin/roles', [\App\Modules\Admin\RolesController::class, 'create'], ['can:roles.manage']);
        $r->get('/admin/roles/{id:\d+}', [\App\Modules\Admin\RolesController::class, 'edit'], ['can:roles.manage']);
        $r->post('/admin/roles/{id:\d+}', [\App\Modules\Admin\RolesController::class, 'save'], ['can:roles.manage']);
        $r->get('/admin/audit', [\App\Modules\Admin\AuditController::class, 'index'], ['can:audit.view']);
        $r->get('/admin/exports', [\App\Modules\Admin\ExportController::class, 'index'], ['can:reports.export']);
        $r->post('/admin/exports', [\App\Modules\Admin\ExportController::class, 'create'], ['can:reports.export']);
        $r->get('/admin/exports/{uid:[0-9a-z]{26}}', [\App\Modules\Admin\ExportController::class, 'download'], ['can:reports.export']);

        $r->get('/admin/backups', [\App\Modules\Admin\BackupController::class, 'index'], ['can:backup.manage']);
        $r->post('/admin/backups', [\App\Modules\Admin\BackupController::class, 'create'], ['can:backup.manage']);
        $r->get('/admin/backups/{name:[a-z]+-[0-9]{8}-[0-9]{6}(?:-[0-9A-Za-z.-]+)?}/{file:database\.sql\.gz|code\.zip}', [\App\Modules\Admin\BackupController::class, 'download'], ['can:backup.manage']);
        $r->post('/admin/backups/{name:[a-z]+-[0-9]{8}-[0-9]{6}(?:-[0-9A-Za-z.-]+)?}/delete', [\App\Modules\Admin\BackupController::class, 'delete'], ['can:backup.manage']);

        $r->get('/admin/settings', [SettingsController::class, 'show'], ['can:settings.manage']);
        $r->get('/admin/letters', [\App\Modules\Admin\OfficialLetterController::class, 'index'], ['can:letters.official']);
        $r->post('/admin/letters', [\App\Modules\Admin\OfficialLetterController::class, 'store'], ['can:letters.official']);
        $r->post('/admin/letters/{uid:[0-9a-z]{26}}/delete', [\App\Modules\Admin\OfficialLetterController::class, 'destroy'], ['can:letters.official']);
        $r->get('/admin/system-update', [\App\Modules\Admin\SystemUpdateController::class, 'show'], ['can:updates.manage']);
        $r->post('/admin/system-update', [\App\Modules\Admin\SystemUpdateController::class, 'upload'], ['can:updates.manage']);
        $r->post('/admin/system-update/export', [\App\Modules\Admin\SystemUpdateController::class, 'export'], ['can:updates.manage']);
        $r->get('/updates', [\App\Modules\Admin\ReleaseNotesController::class, 'index']);
        $r->post('/updates', [\App\Modules\Admin\ReleaseNotesController::class, 'store'], ['can:updates.manage']);
        $r->post('/updates/{id:\d+}/toggle', [\App\Modules\Admin\ReleaseNotesController::class, 'toggle'], ['can:updates.manage']);
        $r->post('/admin/settings', [SettingsController::class, 'update'], ['can:settings.manage']);
        $r->post('/admin/settings/google', [SettingsController::class, 'updateGoogle'], ['can:settings.manage']);
        $r->get('/admin/languages', [\App\Modules\Admin\LanguagesController::class, 'index'], ['can:i18n.manage']);
        $r->post('/admin/languages/settings', [\App\Modules\Admin\LanguagesController::class, 'settings'], ['can:i18n.manage']);
        $r->post('/admin/languages/translate', [\App\Modules\Admin\LanguagesController::class, 'save'], ['can:i18n.manage']);
        $r->post('/admin/languages/reset', [\App\Modules\Admin\LanguagesController::class, 'reset'], ['can:i18n.manage']);
        $r->post('/admin/languages/misses/clear', [\App\Modules\Admin\LanguagesController::class, 'clearMisses'], ['can:i18n.manage']);
        $r->get('/admin/home', [\App\Modules\Admin\HomeAdminController::class, 'show'], ['can:settings.manage']);
        $r->post('/admin/home', [\App\Modules\Admin\HomeAdminController::class, 'update'], ['can:settings.manage']);
        $r->post('/admin/home/reset', [\App\Modules\Admin\HomeAdminController::class, 'reset'], ['can:settings.manage']);
    });

    // Payment gateways return the user here (signed; does not depend on the session).
    $r->get('/payments/callback/{gateway:[a-z0-9_]{2,32}}', [PaymentController::class, 'callback'], ['throttle:payment']);

    // Public business pages
    $r->get('/p/{handle:[a-z0-9-]{3,32}}', [PublicPageController::class, 'show'], ['session:optional']);
    $r->get('/p/{handle:[a-z0-9-]{3,32}}/{lang:[a-z]{2,3}}', [PublicPageController::class, 'show'], ['session:optional']);

    // Operations (token protected, for hosts without SSH)
    $r->get('/health/live', [HealthController::class, 'live']);
    $r->get('/health', [HealthController::class, 'full'], ['throttle:default']);
    $r->post('/ops/migrate', [OpsController::class, 'migrate'], ['throttle:install']);
    $r->post('/ops/promote-admin', [OpsController::class, 'promoteAdmin'], ['throttle:install']);
    $r->post('/ops/wallet-credit', [OpsController::class, 'walletCredit'], ['throttle:install']);
    $r->post('/ops/metrics-backfill', [OpsController::class, 'backfillMetrics'], ['throttle:install']);

    $r->get('/install', [InstallerController::class, 'show'], ['throttle:install']);
    $r->post('/install', [InstallerController::class, 'install'], ['throttle:install']);
};
